export interface Playlist {
    id?: number;
    name: string;
    songs?: any[]; // You might want to replace this with a proper Song model
  }
  