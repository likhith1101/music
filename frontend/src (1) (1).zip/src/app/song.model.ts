 
export interface Song {
    id: number;
    title: string;
    artist: string[];
    musicDirector : string;
    genre: string;
  }
  